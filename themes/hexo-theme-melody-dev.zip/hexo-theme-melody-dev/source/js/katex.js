$(function () {
    $('span.katex-display').wrap('<div class="katex-wrap"></div>')
})
