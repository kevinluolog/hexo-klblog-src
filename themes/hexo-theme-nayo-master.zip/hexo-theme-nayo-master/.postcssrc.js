module.exports = {
    plugins: {
        "autoprefixer": {}
    }
}